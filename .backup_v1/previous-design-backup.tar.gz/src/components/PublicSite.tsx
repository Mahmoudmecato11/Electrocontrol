import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Images,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  X,
  ZoomIn,
} from 'lucide-react';
import type {
  ProjectItem,
  ServiceCategory,
  ServiceItem,
  SiteConfig,
} from '../shared/siteData';
import { MotionConfig, motion } from 'motion/react';
import { ResilientImage } from './ResilientImage';
import { GerberViewer } from './GerberViewer';
import { ImageLightbox, type LightboxImageItem } from './ImageLightbox';
import { Reveal } from './Reveal';

interface PublicSiteProps {
  config: SiteConfig;
  services: ServiceItem[];
  projects: ProjectItem[];
  onOpenAdmin: () => void;
}

const REQUEST_TYPES = [
  'تصنيع PCB من ملفات Gerber',
  'تصميم بوردة PCB ونظام تحكم جديد',
  'معاينة ماكينة لتصنيع نظام تحكم',
  'نظام Industrial IoT / شاشة HMI مخصصة',
  'هندسة عكسية لبوردة قائمة',
  'استفسار فني عام',
];

const CATEGORIES: Array<'الكل' | ServiceCategory> = [
  'الكل',
  'تصنيع PCB',
  'تحكم وأتمتة',
  'إنترنت الأشياء HMI',
];

export function PublicSite({
  config,
  services,
  projects,
  onOpenAdmin,
}: PublicSiteProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [serviceFilter, setServiceFilter] = useState<'الكل' | ServiceCategory>('الكل');
  const [projectFilter, setProjectFilter] = useState<'الكل' | ServiceCategory>('الكل');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [lightboxState, setLightboxState] = useState<{
    images: LightboxImageItem[];
    initialIndex: number;
    project?: ProjectItem;
  } | null>(null);

  // Quote Form state
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [requestType, setRequestType] = useState(REQUEST_TYPES[0]);
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [submittedWhatsappUrl, setSubmittedWhatsappUrl] = useState<string | null>(null);

  const visibleServices = useMemo(() => {
    const active = services.filter((s) => s.visible);
    if (serviceFilter === 'الكل') return active;
    return active.filter((s) => s.category === serviceFilter);
  }, [services, serviceFilter]);

  const visibleProjects = useMemo(
    () => projects.filter((p) => p.visible),
    [projects]
  );

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'الكل') return visibleProjects;
    return visibleProjects.filter((p) => p.category === projectFilter);
  }, [visibleProjects, projectFilter]);

  const getProjectGallery = (prj: ProjectItem): string[] => {
    const raw = [prj.image, ...(prj.gallery || [])].filter(Boolean);
    return Array.from(new Set(raw));
  };

  const openProjectLightbox = (prj: ProjectItem, startIndex = 0) => {
    const urls = getProjectGallery(prj);
    const meta = [prj.category, prj.architecture, prj.region, prj.year]
      .filter(Boolean)
      .join(' · ');
    const images: LightboxImageItem[] = urls.map((src, idx) => ({
      src,
      alt: `${prj.title} - صورة ${idx + 1}`,
      title: prj.title,
      subtitle: meta,
    }));
    setLightboxState({
      images,
      initialIndex: startIndex,
      project: prj,
    });
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedService(null);
        setSelectedProject(null);
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const jumpToQuote = (presetType?: string, presetNote?: string, overwrite = false) => {
    setSelectedService(null);
    setSelectedProject(null);
    setMobileMenuOpen(false);
    if (presetType) setRequestType(presetType);
    if (presetNote && (overwrite || !details.trim())) {
      setDetails(presetNote);
    }
    const el = document.getElementById('quote');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanName = name.trim();
    const cleanPhone = phone.trim();
    const cleanEmail = email.trim();
    const cleanDetails = details.trim();

    if (cleanName.length < 2) {
      setFormError('يرجى كتابة الاسم بشكل صحيح.');
      return;
    }
    if (!/^[+\d\s()-]{8,20}$/.test(cleanPhone)) {
      setFormError('يرجى إدخال رقم تليفون أو واتساب صحيح للتواصل.');
      return;
    }
    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setFormError('صيغة البريد الإلكتروني غير صحيحة.');
      return;
    }
    if (cleanDetails.length < 8) {
      setFormError('يرجى كتابة نبذة مختصرة عن الطلب أو مواصفات البوردة/الماكينة.');
      return;
    }

    const cleanCompany = company.trim();
    const waLines = [
      `السلام عليكم فريق ${config.companyName}،`,
      `طلب جديد من الموقع (${requestType}):`,
      '',
      `• الاسم: ${cleanName}`,
      ...(cleanCompany ? [`• الشركة / المصنع: ${cleanCompany}`] : []),
      `• رقم الموبايل / واتساب: ${cleanPhone}`,
      ...(cleanEmail ? [`• البريد الإلكتروني: ${cleanEmail}`] : []),
      `• نوع الطلب: ${requestType}`,
      '',
      '• تفاصيل المشروع / المواصفات:',
      cleanDetails,
    ];
    const waOrderUrl = `https://wa.me/${cleanWhatsapp}?text=${encodeURIComponent(
      waLines.join('\n')
    )}`;

    // Open WhatsApp synchronously during user submit gesture without window.open
    const waLink = document.createElement('a');
    waLink.href = waOrderUrl;
    waLink.target = '_blank';
    waLink.rel = 'noopener noreferrer';
    waLink.style.display = 'none';
    document.body.appendChild(waLink);
    waLink.click();
    document.body.removeChild(waLink);

    setSubmittedWhatsappUrl(waOrderUrl);
    setSubmitting(true);
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        keepalive: true,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cleanName,
          company: cleanCompany,
          phone: cleanPhone,
          email: cleanEmail,
          requestType,
          details: cleanDetails,
        }),
      });
      const data = await res.json().catch(() => null);
      setSubmittedId(data?.inquiry?.id || `EC-WA-${Date.now().toString().slice(-4)}`);
      setName('');
      setCompany('');
      setPhone('');
      setEmail('');
      setDetails('');
    } catch {
      // WhatsApp message was already prepared and triggered with full client details
      setSubmittedId(`EC-WA-${Date.now().toString().slice(-4)}`);
      setName('');
      setCompany('');
      setPhone('');
      setEmail('');
      setDetails('');
    } finally {
      setSubmitting(false);
    }
  };

  const cleanWhatsapp = (() => {
    const digits = (config.whatsapp || config.phone || '201080269003').replace(/[^\d]/g, '');
    if (digits.startsWith('00')) return digits.slice(2);
    if (digits.startsWith('0') && digits.length === 11) return `2${digits}`;
    return digits || '201080269003';
  })();
  const whatsappUrl = `https://wa.me/${cleanWhatsapp}?text=${encodeURIComponent(
    `أهلاً فريق ${config.companyName}، محتاج أستفسر عن مشروع أو طلب عرض سعر.`
  )}`;
  const cleanTel = (config.phone || '01080269003').replace(/[^\d+]/g, '');
  const logoSrc = config.logoImage || '/assets/aistudio/FB_IMG_1794781004368_3087cab9.jpg';

  return (
    <MotionConfig reducedMotion="user">
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 1-row, 3 zones, gap-8, max height <= 64px */}
      <header className="sticky top-0 z-40 h-16 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          {/* Zone 1: Brand logo + wordmark */}
          <a
            href="#top"
            className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-600 rounded"
          >
            <span className="w-10 h-10 rounded-lg overflow-hidden bg-[#071a2b] border border-slate-200 shrink-0 flex items-center justify-center">
              <ResilientImage
                src={logoSrc}
                alt={`شعار ${config.companyName}`}
                className="w-full h-full object-contain"
              />
            </span>
            <span className="font-latin text-lg font-bold tracking-tight text-slate-900">
              {config.companyName}
            </span>
          </a>

          {/* Zone 2: 5 concise single-line nav links */}
          <nav
            aria-label="التنقل الرئيسي"
            className="hidden md:flex items-center gap-7 text-sm font-semibold text-slate-600"
          >
            <a
              href="#services"
              className="hover:text-slate-900 hover:underline underline-offset-8 decoration-sky-600 transition-colors whitespace-nowrap shrink-0"
            >
              الخدمات
            </a>
            <a
              href="#pcb"
              className="hover:text-slate-900 hover:underline underline-offset-8 decoration-sky-600 transition-colors whitespace-nowrap shrink-0"
            >
              تصنيع PCB
            </a>
            <a
              href="#projects"
              className="hover:text-slate-900 hover:underline underline-offset-8 decoration-sky-600 transition-colors whitespace-nowrap shrink-0"
            >
              المشاريع
            </a>
            <a
              href="#about"
              className="hover:text-slate-900 hover:underline underline-offset-8 decoration-sky-600 transition-colors whitespace-nowrap shrink-0"
            >
              عن الشركة
            </a>
            <button
              type="button"
              onClick={onOpenAdmin}
              className="hover:text-slate-900 hover:underline underline-offset-8 decoration-sky-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              لوحة التحكم
            </button>
          </nav>

          {/* Zone 3: 1 primary CTA + mobile drawer toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => jumpToQuote()}
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-600 focus-visible:ring-offset-2"
            >
              {config.heroPrimaryCta}
            </button>
            <button
              type="button"
              aria-label={mobileMenuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
              aria-expanded={mobileMenuOpen}
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-200 px-4 py-4 shadow-sm">
            <nav className="flex flex-col gap-1">
              <a
                href="#services"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 rounded-lg"
              >
                الخدمات
              </a>
              <a
                href="#pcb"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 rounded-lg"
              >
                تصنيع PCB
              </a>
              <a
                href="#projects"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 rounded-lg"
              >
                المشاريع والأعمال
              </a>
              <a
                href="#about"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 rounded-lg"
              >
                عن الشركة والتواصل
              </a>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="text-right px-3 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 rounded-lg cursor-pointer"
              >
                لوحة التحكم (الإدارة)
              </button>
              <button
                type="button"
                onClick={() => jumpToQuote()}
                className="mt-2 w-full py-2.5 px-4 text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer"
              >
                {config.heroPrimaryCta}
              </button>
            </nav>
          </div>
        )}
      </header>

      <main id="top" className="flex-1">
        {/* 1. Hero Section */}
        <section className="bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16 lg:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
              <Reveal immediate delay={0.04} y={14} className="lg:col-span-6 flex flex-col justify-center">
                <p className="text-sm font-semibold text-sky-700 mb-3">
                  {config.heroEyebrow}
                </p>
                <h1
                  className="headline-balance font-bold text-slate-900 tracking-tight leading-[1.25] mb-5"
                  style={{ fontSize: 'clamp(1.85rem, 3.3vw, 3rem)' }}
                >
                  {config.heroTitle}
                </h1>
                <p className="text-base md:text-lg text-slate-600 leading-relaxed max-w-2xl mb-8">
                  {config.heroSubtitle}
                </p>

                <div className="flex flex-wrap items-center gap-3 sm:gap-4 mb-8">
                  <button
                    type="button"
                    onClick={() => jumpToQuote()}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm md:text-base font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-600 focus-visible:ring-offset-2"
                  >
                    <span>{config.heroPrimaryCta}</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm md:text-base font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>تواصل واتساب</span>
                  </a>
                  <a
                    href="#services"
                    className="inline-flex items-center justify-center px-5 py-3 text-sm md:text-base font-semibold text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-slate-300 bg-white rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    {config.heroSecondaryCta}
                  </a>
                </div>

                <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs sm:text-sm text-slate-500 pt-5 border-t border-slate-100">
                  <span className="tabular-nums">{config.workingHours}</span>
                  <span aria-hidden="true">·</span>
                  <span>{config.regions}</span>
                </div>
              </Reveal>

              <Reveal immediate delay={0.12} y={16} className="lg:col-span-6">
                <div className="h-full min-h-[240px] sm:min-h-[340px] lg:min-h-[420px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                  <ResilientImage
                    src={config.heroImage}
                    alt="معمل تطوير واختبار أنظمة التحكم وبوردات الـ PCB في Electro Control"
                    className="w-full h-full object-cover"
                  />
                </div>
              </Reveal>
            </div>
          </div>

          {/* 4-Column Factual Capability Strip */}
          <div className="border-t border-slate-200 bg-slate-50/70">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 divide-slate-200">
                {config.capabilities.map((cap, idx) => (
                  <Reveal
                    key={cap.id}
                    delay={idx * 0.05}
                    y={10}
                    className={`py-5 px-3 sm:px-6 ${idx === 0 ? 'lg:pr-0' : ''} ${
                      idx < config.capabilities.length - 1 ? 'lg:border-e lg:border-slate-200' : ''
                    }`}
                  >
                    <div className="text-xs text-slate-500 mb-1">{cap.label}</div>
                    <div className="font-latin text-sm sm:text-base font-bold text-slate-900 tabular-nums">
                      {cap.value}
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 2. Core Services & PCB Highlight */}
        <section id="services" className="py-14 md:py-20 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Reveal className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
              <div>
                <h2 className="headline-balance text-2xl md:text-3xl font-bold text-slate-900 mb-2">
                  الخدمات الهندسية والتصنيع
                </h2>
                <p className="text-slate-600 text-sm md:text-base max-w-2xl">
                  بنقدم حلول عملية متكاملة بداية من تصميم وتصنيع البوردة لحد البرمجة والتركيب، بدون تعقيد.
                </p>
              </div>

              {/* Interactive Filter Controls */}
              <div
                role="tablist"
                aria-label="تصفية الخدمات"
                className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start"
              >
                {CATEGORIES.map((cat) => {
                  const active = serviceFilter === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setServiceFilter(cat)}
                      className={`px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </Reveal>

            {visibleServices.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-slate-500">
                لا توجد خدمات ظاهرة في هذا التصنيف حالياً.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {visibleServices.map((srv, idx) => (
                  <motion.article
                    key={srv.id}
                    initial={{ opacity: 0, y: 18 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.06 }}
                    transition={{
                      duration: 0.45,
                      delay: (idx % 2) * 0.08,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col hover:border-slate-300 transition-colors"
                  >
                    <div className="aspect-[16/10] w-full bg-slate-100 border-b border-slate-200 overflow-hidden">
                      <ResilientImage
                        src={srv.image}
                        alt={srv.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-6 flex-1 flex flex-col">
                      <div className="text-xs text-slate-500 mb-2 flex items-center gap-2">
                        <span className="font-mono-tech font-semibold text-sky-700">
                          {srv.orderLabel}.
                        </span>
                        <span>{srv.category}</span>
                      </div>
                      <h3 className="text-lg md:text-xl font-bold text-slate-900 mb-2.5">
                        {srv.title}
                      </h3>
                      <p className="text-sm text-slate-600 leading-relaxed mb-4">
                        {srv.shortDesc}
                      </p>
                      <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700 mb-6 flex-1">
                        {srv.specs.slice(0, 3).map((spec, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-sky-700 font-bold leading-5" aria-hidden="true">
                              •
                            </span>
                            <span>{spec}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
                        <button
                          type="button"
                          onClick={() => setSelectedService(srv)}
                          className="text-sm font-semibold text-sky-700 hover:text-sky-800 cursor-pointer whitespace-nowrap"
                        >
                          عرض المواصفات كاملة
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            jumpToQuote(
                              srv.category === 'تصنيع PCB'
                                ? 'تصنيع PCB من ملفات Gerber'
                                : srv.category === 'إنترنت الأشياء HMI'
                                ? 'نظام Industrial IoT / شاشة HMI مخصصة'
                                : 'تصميم بوردة PCB ونظام تحكم جديد',
                              `استفسار بخصوص: ${srv.title}`
                            )
                          }
                          className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          اطلب تسعير
                        </button>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </div>
            )}

            {/* Dedicated PCB Manufacturing Callout Band (No thick left bar, clean subtle contrast) */}
            <Reveal delay={0.05}>
              <div
                id="pcb"
                className="mt-10 bg-slate-900 text-white rounded-xl p-6 sm:p-8 lg:p-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6"
              >
                <div className="max-w-2xl">
                  <p className="text-xs font-semibold text-sky-400 mb-2">
                    خدمة تصنيع الـ PCB في مصر
                  </p>
                  <h3 className="headline-balance text-xl sm:text-2xl font-bold mb-2">
                    {config.pcbBannerTitle}
                  </h3>
                  <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                    {config.pcbBannerBody}
                  </p>
                </div>
                <div className="shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      jumpToQuote(
                        'تصنيع PCB من ملفات Gerber',
                        'محتاج تسعير تصنيع PCB — الكمية المطلوبة: ... / هل ملفات Gerber جاهزة: ...'
                      )
                    }
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>اطلب تصنيع PCB الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.08}>
              <GerberViewer
                onUseForQuote={(summary) =>
                  jumpToQuote('تصنيع PCB من ملفات Gerber', summary, true)
                }
              />
            </Reveal>
          </div>
        </section>

        {/* 3. Past Engineering Projects Showcase Grid */}
        <section id="projects" className="py-14 md:py-20 bg-white border-t border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Reveal className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
              <div>
                <h2 className="headline-balance text-2xl md:text-3xl font-bold text-slate-900 mb-2">
                  مشاريعنا السابقة ونماذج الأعمال
                </h2>
                <p className="text-slate-600 text-sm md:text-base max-w-2xl">
                  نماذج حقيقية لبوردات PCB ولوحات تحكم وأنظمة IoT تم تصميمها وتصنيعها واختبارها للتشغيل الفعلي. اضغط على أي صورة لتكبير التفاصيل.
                </p>
              </div>

              <div className="flex flex-wrap gap-2" role="tablist" aria-label="تصنيف المشاريع السابقة">
                {CATEGORIES.map((cat) => {
                  const active = projectFilter === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setProjectFilter(cat)}
                      className={`px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                        active
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-slate-300 hover:text-slate-900'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </Reveal>

            {filteredProjects.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-10 text-center text-slate-500">
                لا توجد مشاريع في هذا التصنيف حالياً.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProjects.map((prj, idx) => {
                  const galleryUrls = getProjectGallery(prj);
                  return (
                    <motion.article
                      key={prj.id}
                      initial={{ opacity: 0, y: 18 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, amount: 0.06 }}
                      transition={{
                        duration: 0.45,
                        delay: (idx % 3) * 0.07,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                      className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden flex flex-col hover:border-slate-300 hover:shadow-md transition-all"
                    >
                      {/* Clickable Image Stage with Hover Scale & Zoom Control */}
                      <div className="group relative aspect-[16/10] w-full bg-slate-100 border-b border-slate-200 overflow-hidden">
                        <button
                          type="button"
                          onClick={() => openProjectLightbox(prj, 0)}
                          aria-label={`تكبير صورة مشروع ${prj.title}`}
                          className="block w-full h-full text-right cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-sky-600"
                        >
                          <ResilientImage
                            src={prj.image}
                            alt={prj.title}
                            className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-105"
                          />
                          <div
                            aria-hidden="true"
                            className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/20 transition-colors duration-200"
                          />
                          <span className="absolute top-3 left-3 inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/95 border border-slate-200 text-slate-800 text-xs font-semibold shadow-xs group-hover:bg-sky-700 group-hover:text-white group-hover:border-sky-700 transition-colors">
                            <ZoomIn className="w-3.5 h-3.5" />
                            <span>تكبير</span>
                          </span>
                        </button>
                      </div>

                      {/* Mini Gallery Thumbnails when project has multiple images */}
                      {galleryUrls.length > 1 && (
                        <div className="px-4 pt-3 flex items-center gap-2 overflow-x-auto">
                          {galleryUrls.map((url, idx) => (
                            <button
                              key={`${prj.id}-thumb-${idx}`}
                              type="button"
                              onClick={() => openProjectLightbox(prj, idx)}
                              aria-label={`تكبير الصورة ${idx + 1} من ${prj.title}`}
                              className="w-12 h-9 rounded-md overflow-hidden border border-slate-200 hover:border-sky-600 shrink-0 cursor-zoom-in transition-colors"
                            >
                              <ResilientImage
                                src={url}
                                alt={`${prj.title} - ${idx + 1}`}
                                className="w-full h-full object-cover"
                              />
                            </button>
                          ))}
                          <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap flex items-center gap-1 ms-auto">
                            <Images className="w-3.5 h-3.5 text-slate-400" />
                            <span>{galleryUrls.length} صور</span>
                          </span>
                        </div>
                      )}

                      <div className="p-5 sm:p-6 flex-1 flex flex-col">
                        {/* Zero-Pill unboxed metadata */}
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-2">
                          <span>{prj.category}</span>
                          {prj.year && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono-tech tabular-nums text-slate-600">
                                {prj.year}
                              </span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>{prj.region}</span>
                        </div>
                        <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-1.5">
                          {prj.title}
                        </h3>
                        {prj.architecture && (
                          <div className="font-mono-tech text-xs text-sky-800 mb-2.5 truncate">
                            {prj.architecture}
                          </div>
                        )}
                        <p className="text-sm text-slate-600 leading-relaxed mb-5 flex-1 line-clamp-3">
                          {prj.summary}
                        </p>
                        <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between gap-3">
                          <button
                            type="button"
                            onClick={() => setSelectedProject(prj)}
                            className="text-sm font-semibold text-sky-700 hover:text-sky-800 cursor-pointer"
                          >
                            تفاصيل المواصفات الفنية
                          </button>
                          <button
                            type="button"
                            onClick={() => openProjectLightbox(prj, 0)}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
                          >
                            <ZoomIn className="w-3.5 h-3.5" />
                            <span>معاينة الصورة</span>
                          </button>
                        </div>
                      </div>
                    </motion.article>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {/* 4. About & Direct Quote / Machine Inspection Form */}
        <section id="quote" className="py-14 md:py-20 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
              {/* Company Info & Clarity */}
              <Reveal className="lg:col-span-5 space-y-6">
                <div id="about">
                  <h2 className="headline-balance text-2xl md:text-3xl font-bold text-slate-900 mb-3">
                    {config.aboutTitle}
                  </h2>
                  <p className="text-sm md:text-base text-slate-600 leading-relaxed">
                    {config.aboutBody}
                  </p>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-bold text-slate-900">مواعيد العمل</div>
                      <div className="text-sm text-slate-700 tabular-nums mt-0.5">
                        {config.workingHours}
                      </div>
                      <div className="text-xs text-slate-500 mt-1 leading-relaxed">
                        {config.workingDaysNote}
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-slate-100 pt-4 flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-bold text-slate-900">نطاق العمل والشحن</div>
                      <div className="text-sm text-slate-600 mt-0.5">{config.regions}</div>
                    </div>
                  </div>

                  <div className="border-t border-slate-100 pt-4 text-xs text-slate-600 leading-relaxed">
                    <strong className="text-slate-900">ملاحظة التسعير والمعاينة: </strong>
                    {config.quotationTermsNote}
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                  <div className="text-sm font-bold text-slate-900 mb-1">
                    قنوات التواصل المباشر
                  </div>
                  <a
                    href={`tel:${cleanTel}`}
                    className="flex items-center justify-between py-2 text-sm text-slate-700 hover:text-sky-700 border-b border-slate-100"
                  >
                    <span className="flex items-center gap-2.5">
                      <Phone className="w-4 h-4 text-slate-400" />
                      <span>التليفون المباشر</span>
                    </span>
                    <span className="font-mono-tech text-left font-semibold" dir="ltr">
                      {config.phone}
                    </span>
                  </a>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between py-2 text-sm text-slate-700 hover:text-emerald-700 border-b border-slate-100"
                  >
                    <span className="flex items-center gap-2.5">
                      <MessageCircle className="w-4 h-4 text-emerald-600" />
                      <span>واتساب</span>
                    </span>
                    <span className="font-mono-tech text-left font-semibold" dir="ltr">
                      {config.phone}
                    </span>
                  </a>
                  <a
                    href={`mailto:${config.email}`}
                    className="flex items-center justify-between py-2 text-sm text-slate-700 hover:text-sky-700"
                  >
                    <span className="flex items-center gap-2.5">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <span>البريد الإلكتروني</span>
                    </span>
                    <span className="font-mono-tech text-left" dir="ltr">
                      {config.email}
                    </span>
                  </a>

                  <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>محادثة واتساب الآن</span>
                    </a>
                    <a
                      href={`tel:${cleanTel}`}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      <span>اتصال هاتفي</span>
                    </a>
                  </div>
                </div>
              </Reveal>

              {/* Clean Lead / Quote Capture Form */}
              <Reveal delay={0.08} className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
                <h3 className="text-xl font-bold text-slate-900 mb-1.5">
                  اطلب عرض سعر أو معاينة فنية
                </h3>
                <p className="text-sm text-slate-600 mb-6">
                  ابعتلنا تفاصيل مشروعك أو مواصفات البوردة، وفريقنا الهندسي هيراجعها ويرد عليك.
                </p>

                {submittedId ? (
                  <div className="py-8 text-center space-y-4">
                    <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                    <h4 className="text-lg font-bold text-slate-900">
                      تم استلام طلبك بنجاح
                    </h4>
                    <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                      رقم الطلب المرجعي:{' '}
                      <span className="font-mono-tech font-semibold text-slate-900">
                        {submittedId}
                      </span>
                      <br />
                      فريقنا الهندسي هيراجع التفاصيل ويتواصل معاك خلال ساعات العمل ({config.workingHours}).
                    </p>
                    <div className="pt-2 flex flex-wrap justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setSubmittedId(null);
                          setSubmittedWhatsappUrl(null);
                        }}
                        className="px-5 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                      >
                        إرسال طلب آخر
                      </button>
                      <a
                        href={submittedWhatsappUrl || whatsappUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>إرسال الطلب عبر واتساب</span>
                      </a>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                    {formError && (
                      <div
                        role="alert"
                        className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700 font-medium"
                      >
                        {formError}
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="q-name"
                          className="block text-sm font-semibold text-slate-700 mb-1.5"
                        >
                          الاسم <span className="text-red-600">*</span>
                        </label>
                        <input
                          id="q-name"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="مثال: م. محمد علي"
                          className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="q-company"
                          className="block text-sm font-semibold text-slate-700 mb-1.5"
                        >
                          الشركة / المصنع (اختياري)
                        </label>
                        <input
                          id="q-company"
                          type="text"
                          value={company}
                          onChange={(e) => setCompany(e.target.value)}
                          placeholder="اسم المصنع أو الشركة"
                          className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="q-phone"
                          className="block text-sm font-semibold text-slate-700 mb-1.5"
                        >
                          رقم الموبايل / واتساب <span className="text-red-600">*</span>
                        </label>
                        <input
                          id="q-phone"
                          type="tel"
                          required
                          dir="ltr"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="01000000000"
                          className="w-full px-3.5 py-2.5 text-sm text-right bg-white border border-slate-300 rounded-lg font-mono-tech focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="q-email"
                          className="block text-sm font-semibold text-slate-700 mb-1.5"
                        >
                          البريد الإلكتروني (اختياري)
                        </label>
                        <input
                          id="q-email"
                          type="email"
                          dir="ltr"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="name@company.com"
                          className="w-full px-3.5 py-2.5 text-sm text-right bg-white border border-slate-300 rounded-lg font-latin focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="q-type"
                        className="block text-sm font-semibold text-slate-700 mb-1.5"
                      >
                        نوع الطلب
                      </label>
                      <select
                        id="q-type"
                        value={requestType}
                        onChange={(e) => setRequestType(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                      >
                        {REQUEST_TYPES.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="q-details"
                        className="block text-sm font-semibold text-slate-700 mb-1.5"
                      >
                        تفاصيل المشروع أو المواصفات <span className="text-red-600">*</span>
                      </label>
                      <textarea
                        id="q-details"
                        rows={4}
                        required
                        value={details}
                        onChange={(e) => setDetails(e.target.value)}
                        placeholder="اكتب باختصار المطلوب: عدد البوردات أو نوع الماكينة، الجهود المطلوبة (24V / 220V)، وهل في ملفات Gerber جاهزة..."
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-sky-600 focus:ring-2 focus:ring-sky-600/20"
                      />
                    </div>

                    <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <button
                        type="submit"
                        disabled={submitting}
                        className="px-6 py-3 text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        {submitting ? 'جاري الإرسال...' : 'إرسال الطلب للفريق الهندسي'}
                      </button>
                      <span className="text-xs text-slate-500">
                        المتابعة تتم مباشرة عبر فريقنا الهندسي.
                      </span>
                    </div>
                  </form>
                )}
              </Reveal>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
        <Reveal y={12} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-slate-800">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl overflow-hidden bg-[#071a2b] border border-slate-700 shrink-0 flex items-center justify-center">
                <ResilientImage
                  src={logoSrc}
                  alt={`شعار ${config.companyName}`}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <div className="font-latin text-lg font-bold text-white mb-0.5">
                  {config.companyName}
                </div>
                <div className="text-xs sm:text-sm text-slate-400">
                  {config.workingHours} · {config.regions}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-6 text-sm">
              <a href="#services" className="hover:text-white transition-colors">
                الخدمات
              </a>
              <a href="#pcb" className="hover:text-white transition-colors">
                تصنيع PCB
              </a>
              <a href="#projects" className="hover:text-white transition-colors">
                المشاريع
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>واتساب ({config.phone})</span>
              </a>
              <button
                type="button"
                onClick={onOpenAdmin}
                className="text-sky-400 hover:text-sky-300 font-semibold transition-colors cursor-pointer"
              >
                لوحة تحكم الإدارة
              </button>
            </div>
          </div>
          <div className="pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
            <div>
              © {new Date().getFullYear()} {config.companyName} — جميع الحقوق محفوظة.
            </div>
            <div className="font-mono-tech">{config.domain}</div>
          </div>
        </Reveal>
      </footer>

      {/* Service Details Modal */}
      {selectedService && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedService.title}
          onClick={() => setSelectedService(null)}
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-xl"
          >
            <div className="aspect-[16/9] w-full bg-slate-100 border-b border-slate-200 relative">
              <ResilientImage
                src={selectedService.image}
                alt={selectedService.title}
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                aria-label="إغلاق"
                onClick={() => setSelectedService(null)}
                className="absolute top-3 left-3 w-10 h-10 rounded-lg bg-white/95 text-slate-800 border border-slate-200 flex items-center justify-center hover:bg-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 sm:p-8">
              <div className="text-xs text-slate-500 mb-2">
                <span className="font-mono-tech font-semibold text-sky-700">
                  {selectedService.orderLabel}.
                </span>{' '}
                {selectedService.category}
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-3">
                {selectedService.title}
              </h3>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
                {selectedService.fullDesc}
              </p>
              <div className="border-t border-slate-100 pt-4 mb-6">
                <h4 className="text-sm font-bold text-slate-900 mb-3">
                  المواصفات والنقاط الفنية
                </h4>
                <ul className="space-y-2 text-sm text-slate-700">
                  {selectedService.specs.map((sp, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-sky-700 font-bold" aria-hidden="true">
                        •
                      </span>
                      <span>{sp}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-wrap items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedService(null)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  إغلاق
                </button>
                <button
                  type="button"
                  onClick={() =>
                    jumpToQuote(
                      selectedService.category === 'تصنيع PCB'
                        ? 'تصنيع PCB من ملفات Gerber'
                        : selectedService.category === 'إنترنت الأشياء HMI'
                        ? 'نظام Industrial IoT / شاشة HMI مخصصة'
                        : 'تصميم بوردة PCB ونظام تحكم جديد',
                      `طلب تسعير بخصوص: ${selectedService.title}`
                    )
                  }
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer"
                >
                  اطلب تسعير لهذه الخدمة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Project Details Modal */}
      {selectedProject && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedProject.title}
          onClick={() => setSelectedProject(null)}
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-xl"
          >
            <div className="aspect-[16/9] w-full bg-slate-100 border-b border-slate-200 relative group">
              <button
                type="button"
                onClick={() => openProjectLightbox(selectedProject, 0)}
                aria-label="تكبير صورة المشروع"
                className="block w-full h-full cursor-zoom-in"
              >
                <ResilientImage
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/85 text-white text-xs font-semibold shadow-sm hover:bg-sky-700 transition-colors">
                  <ZoomIn className="w-3.5 h-3.5" />
                  <span>تكبير الصورة</span>
                </span>
              </button>
              <button
                type="button"
                aria-label="إغلاق"
                onClick={() => setSelectedProject(null)}
                className="absolute top-3 left-3 w-10 h-10 rounded-lg bg-white/95 text-slate-800 border border-slate-200 flex items-center justify-center hover:bg-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {getProjectGallery(selectedProject).length > 1 && (
              <div className="px-6 pt-4 flex items-center gap-2 overflow-x-auto">
                {getProjectGallery(selectedProject).map((url, idx) => (
                  <button
                    key={`modal-thumb-${idx}`}
                    type="button"
                    onClick={() => openProjectLightbox(selectedProject, idx)}
                    aria-label={`تكبير الصورة ${idx + 1}`}
                    className="w-16 h-11 rounded-md overflow-hidden border border-slate-200 hover:border-sky-600 shrink-0 cursor-zoom-in"
                  >
                    <ResilientImage
                      src={url}
                      alt={`${selectedProject.title} - ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}

            <div className="p-6 sm:p-8">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-2">
                <span>{selectedProject.category}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tech text-slate-700">
                  {selectedProject.architecture}
                </span>
                <span aria-hidden="true">·</span>
                <span>{selectedProject.region}</span>
                {selectedProject.year && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tech tabular-nums">{selectedProject.year}</span>
                  </>
                )}
                {selectedProject.client && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>{selectedProject.client}</span>
                  </>
                )}
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-3">
                {selectedProject.title}
              </h3>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
                {selectedProject.summary}
              </p>
              <div className="border-t border-slate-100 pt-4 mb-6">
                <h4 className="text-sm font-bold text-slate-900 mb-3">
                  المواصفات المنفذة
                </h4>
                <ul className="space-y-2 text-sm text-slate-700">
                  {selectedProject.specs.map((sp, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-sky-700 font-bold" aria-hidden="true">
                        •
                      </span>
                      <span>{sp}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-wrap items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  إغلاق
                </button>
                <button
                  type="button"
                  onClick={() =>
                    jumpToQuote(
                      'تصميم بوردة PCB ونظام تحكم جديد',
                      `محتاج تنفيذ نظام مشابه لمشروع: ${selectedProject.title}`
                    )
                  }
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer"
                >
                  اطلب تنفيذ نظام مشابه
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Image Lightbox / Zoom Modal */}
      {lightboxState && (
        <ImageLightbox
          images={lightboxState.images}
          initialIndex={lightboxState.initialIndex}
          onClose={() => setLightboxState(null)}
          onOpenSpecs={
            lightboxState.project
              ? () => {
                  const prj = lightboxState.project!;
                  setLightboxState(null);
                  setSelectedProject(prj);
                }
              : undefined
          }
          onRequestSimilar={
            lightboxState.project
              ? () => {
                  const prj = lightboxState.project!;
                  setLightboxState(null);
                  jumpToQuote(
                    'تصميم بوردة PCB ونظام تحكم جديد',
                    `محتاج تنفيذ نظام مشابه لمشروع: ${prj.title}`
                  );
                }
              : undefined
          }
        />
      )}
      {/* Floating Quick WhatsApp Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noreferrer"
        aria-label="تواصل معنا عبر واتساب"
        className="fixed bottom-5 left-5 z-30 inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold shadow-lg transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2"
      >
        <MessageCircle className="w-5 h-5 shrink-0" />
        <span>واتساب مباشر</span>
      </a>
    </div>
    </MotionConfig>
  );
}
