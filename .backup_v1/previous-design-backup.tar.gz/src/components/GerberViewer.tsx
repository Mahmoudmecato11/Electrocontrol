import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
} from 'react';
import {
  Box,
  Check,
  Eye,
  FileArchive,
  Layers,
  Maximize2,
  Upload,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  parseGerberInputFiles,
  type DrawCommand,
  type GerberLayerKind,
  type ParsedBoard,
  type ParsedLayer,
} from '../utils/gerberParser';
import { Gerber3DViewer } from './Gerber3DViewer';

interface GerberViewerProps {
  onUseForQuote: (summary: string) => void;
}

type ViewMode = 'both' | 'top' | 'bottom' | '3d';
type FinishType = 'HASL' | 'ENIG';

interface MaskTheme {
  id: string;
  label: string;
  boardBg: string;
  copperUnderMask: string;
  silkColor: string;
  swatch: string;
}

const MASK_THEMES: MaskTheme[] = [
  {
    id: 'green',
    label: 'أخضر',
    boardBg: '#0D5C31',
    copperUnderMask: '#1B8F4E',
    silkColor: '#F8FAFC',
    swatch: '#15803D',
  },
  {
    id: 'black',
    label: 'أسود',
    boardBg: '#1C2024',
    copperUnderMask: '#333A42',
    silkColor: '#F1F5F9',
    swatch: '#18181B',
  },
  {
    id: 'blue',
    label: 'أزرق',
    boardBg: '#0C4380',
    copperUnderMask: '#1C6AC2',
    silkColor: '#F8FAFC',
    swatch: '#1D4ED8',
  },
  {
    id: 'red',
    label: 'أحمر',
    boardBg: '#8E1919',
    copperUnderMask: '#C62E2E',
    silkColor: '#F8FAFC',
    swatch: '#B91C1C',
  },
  {
    id: 'white',
    label: 'أبيض',
    boardBg: '#E6E9ED',
    copperUnderMask: '#CBD2D9',
    silkColor: '#1E293B',
    swatch: '#F1F5F9',
  },
  {
    id: 'yellow',
    label: 'أصفر',
    boardBg: '#C48A0E',
    copperUnderMask: '#E1A726',
    silkColor: '#1E293B',
    swatch: '#D97706',
  },
];

const LAYER_LABELS: Record<GerberLayerKind, string> = {
  topCopper: 'نحاس علوي (Top Copper)',
  bottomCopper: 'نحاس سفلي (Bottom Copper)',
  topMask: 'قناع علوي (Top Mask)',
  bottomMask: 'قناع سفلي (Bottom Mask)',
  topSilk: 'طباعة علوية (Top Silk)',
  bottomSilk: 'طباعة سفلية (Bottom Silk)',
  outline: 'حدود البوردة (Outline)',
  drill: 'ملف الثقوب (Drill)',
  unknown: 'ملف إضافي',
};

function drawCommands(
  ctx: CanvasRenderingContext2D,
  commands: DrawCommand[],
  color: string,
  clearColor: string
) {
  for (const cmd of commands) {
    const strokeOrFill = cmd.polarity === 'clear' ? clearColor : color;
    ctx.strokeStyle = strokeOrFill;
    ctx.fillStyle = strokeOrFill;

    if (cmd.kind === 'line') {
      ctx.lineWidth = cmd.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(cmd.x1, cmd.y1);
      ctx.lineTo(cmd.x2, cmd.y2);
      ctx.stroke();
    } else if (cmd.kind === 'arc') {
      const r = Math.hypot(cmd.x1 - cmd.cx, cmd.y1 - cmd.cy);
      const startAngle = Math.atan2(cmd.y1 - cmd.cy, cmd.x1 - cmd.cx);
      const endAngle = Math.atan2(cmd.y2 - cmd.cy, cmd.x2 - cmd.cx);
      ctx.lineWidth = cmd.width;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(cmd.cx, cmd.cy, r, startAngle, endAngle, !cmd.ccw);
      ctx.stroke();
    } else if (cmd.kind === 'flash') {
      const { shape, width, height } = cmd.aperture;
      if (shape === 'R') {
        ctx.fillRect(cmd.x - width / 2, cmd.y - height / 2, width, height);
      } else if (shape === 'O') {
        const rx = width / 2;
        const ry = height / 2;
        const r = Math.min(rx, ry);
        ctx.beginPath();
        ctx.roundRect(cmd.x - rx, cmd.y - ry, width, height, r);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.arc(cmd.x, cmd.y, width / 2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (cmd.kind === 'region' && cmd.points.length >= 3) {
      ctx.beginPath();
      ctx.moveTo(cmd.points[0].x, cmd.points[0].y);
      for (let i = 1; i < cmd.points.length; i++) {
        ctx.lineTo(cmd.points[i].x, cmd.points[i].y);
      }
      ctx.closePath();
      ctx.fill();
    }
  }
}

interface PcbSideCanvasProps {
  side: 'top' | 'bottom';
  board: ParsedBoard;
  theme: MaskTheme;
  finish: FinishType;
  zoom: number;
  showCopper: boolean;
  showMask: boolean;
  showSilk: boolean;
  showDrill: boolean;
}

function PcbSideCanvas({
  side,
  board,
  theme,
  finish,
  zoom,
  showCopper,
  showMask,
  showSilk,
  showDrill,
}: PcbSideCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ active: boolean; startX: number; startY: number; origX: number; origY: number }>({
    active: false,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
  });

  useEffect(() => {
    setPan({ x: 0, y: 0 });
  }, [board.archiveName, zoom]);

  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    const cssW = Math.max(rect.width, 300);
    const cssH = Math.max(rect.height, 260);
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.scale(dpr, dpr);

    // Workbench canvas background (JLCPCB-style dark blueprint grid)
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(0, 0, cssW, cssH);

    // Subtle technical dot/grid lines
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
    ctx.lineWidth = 1;
    const step = 24;
    for (let gx = 0; gx < cssW; gx += step) {
      ctx.beginPath();
      ctx.moveTo(gx, 0);
      ctx.lineTo(gx, cssH);
      ctx.stroke();
    }
    for (let gy = 0; gy < cssH; gy += step) {
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(cssW, gy);
      ctx.stroke();
    }

    const { bounds, widthMm, heightMm, layers } = board;
    const padding = 28;
    const baseScale = Math.min(
      (cssW - padding * 2) / Math.max(widthMm, 1),
      (cssH - padding * 2) / Math.max(heightMm, 1)
    );
    const scale = baseScale * zoom;

    const midX = (bounds.minX + bounds.maxX) / 2;
    const midY = (bounds.minY + bounds.maxY) / 2;

    ctx.translate(cssW / 2 + pan.x, cssH / 2 + pan.y);
    // Flip Y so Gerber Y-up matches screen coordinates; mirror X on Bottom view just like flipping a real PCB!
    ctx.scale(side === 'bottom' ? -scale : scale, -scale);
    ctx.translate(-midX, -midY);

    // 1. PCB Board Substrate / Solder Mask body
    ctx.fillStyle = theme.boardBg;
    ctx.fillRect(bounds.minX, bounds.minY, widthMm, heightMm);

    const findLayers = (kind: GerberLayerKind): ParsedLayer[] =>
      layers.filter((l) => l.kind === kind);

    const copperLayers = findLayers(side === 'top' ? 'topCopper' : 'bottomCopper');
    const maskLayers = findLayers(side === 'top' ? 'topMask' : 'bottomMask');
    const silkLayers = findLayers(side === 'top' ? 'topSilk' : 'bottomSilk');
    const outlineLayers = findLayers('outline');
    const drillLayers = findLayers('drill');

    // 2. Copper under Solder Mask
    if (showCopper) {
      for (const l of copperLayers) {
        drawCommands(ctx, l.commands, theme.copperUnderMask, theme.boardBg);
      }
    }

    // 3. Exposed Pads (Mask Openings -> HASL Silver or ENIG Gold)
    const padColor = finish === 'ENIG' ? '#E3BA59' : '#D5DCE3';
    if (showMask) {
      if (maskLayers.length > 0) {
        for (const l of maskLayers) {
          drawCommands(ctx, l.commands, padColor, theme.boardBg);
        }
      } else if (showCopper) {
        // Fallback: highlight flashed pads if no separate mask file was provided
        for (const l of copperLayers) {
          const padFlashes = l.commands.filter((c) => c.kind === 'flash');
          drawCommands(ctx, padFlashes, padColor, theme.boardBg);
        }
      }
    }

    // 4. Silkscreen
    if (showSilk) {
      for (const l of silkLayers) {
        drawCommands(ctx, l.commands, theme.silkColor, theme.boardBg);
      }
    }

    // 5. Board Outline Edge
    if (outlineLayers.length > 0) {
      for (const l of outlineLayers) {
        drawCommands(ctx, l.commands, '#94A3B8', theme.boardBg);
      }
    } else {
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = Math.max(0.25, 1.2 / scale);
      ctx.strokeRect(bounds.minX, bounds.minY, widthMm, heightMm);
    }

    // 6. Drill Holes (cut through all layers)
    if (showDrill) {
      for (const l of drillLayers) {
        drawCommands(ctx, l.commands, '#0B1120', '#0B1120');
      }
    }

    ctx.restore();
  }, [board, finish, pan, showCopper, showDrill, showMask, showSilk, side, theme, zoom]);

  useEffect(() => {
    renderCanvas();
    const onResize = () => renderCanvas();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [renderCanvas]);

  return (
    <div className="bg-slate-900 border border-slate-700 rounded-xl overflow-hidden flex flex-col">
      <div className="px-4 py-2.5 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between text-xs">
        <span className="font-semibold text-white">
          {side === 'top' ? 'الوجه العلوي (Top View)' : 'الوجه السفلي (Bottom View · معكوس)'}
        </span>
        <span className="font-mono-tech text-slate-400 tabular-nums">
          {board.widthMm} × {board.heightMm} mm
        </span>
      </div>
      <div className="relative w-full h-[270px] sm:h-[320px] select-none cursor-grab active:cursor-grabbing">
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
          onPointerDown={(e) => {
            (e.currentTarget as HTMLCanvasElement).setPointerCapture(e.pointerId);
            dragRef.current = {
              active: true,
              startX: e.clientX,
              startY: e.clientY,
              origX: pan.x,
              origY: pan.y,
            };
          }}
          onPointerMove={(e) => {
            if (!dragRef.current.active) return;
            setPan({
              x: dragRef.current.origX + (e.clientX - dragRef.current.startX),
              y: dragRef.current.origY + (e.clientY - dragRef.current.startY),
            });
          }}
          onPointerUp={() => {
            dragRef.current.active = false;
          }}
          onPointerCancel={() => {
            dragRef.current.active = false;
          }}
        />
      </div>
    </div>
  );
}

export function GerberViewer({ onUseForQuote }: GerberViewerProps) {
  const [board, setBoard] = useState<ParsedBoard | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const [viewMode, setViewMode] = useState<ViewMode>('both');
  const [maskTheme, setMaskTheme] = useState<MaskTheme>(MASK_THEMES[0]);
  const [finish, setFinish] = useState<FinishType>('HASL');
  const [zoom, setZoom] = useState(1);

  const [showCopper, setShowCopper] = useState(true);
  const [showMask, setShowMask] = useState(true);
  const [showSilk, setShowSilk] = useState(true);
  const [showDrill, setShowDrill] = useState(true);
  const [showFilesList, setShowFilesList] = useState(false);
  const [fullscreen3D, setFullscreen3D] = useState(false);

  useEffect(() => {
    if (!fullscreen3D) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setFullscreen3D(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [fullscreen3D]);

  const handleFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setError('');
    setLoading(true);
    try {
      const files = Array.from(fileList);
      const parsed = await parseGerberInputFiles(files);
      if (parsed.layers.length === 0) {
        setError(
          'لم يتم التعرف على طبقات Gerber صالحة داخل الملف. تأكد أن الملف مضغوط بصيغة ZIP ويحتوي على ملفات (.GTL, .GBL, .GTS, .GBS, .GTO, .GKO, .DRL).'
        );
        return;
      }
      setBoard(parsed);
      setZoom(1);
      setShowFilesList(false);
    } catch {
      setError('تعذر قراءة ملف الـ Gerber. تأكد أنه ملف ZIP سليم أو ملفات Gerber قياسية.');
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleQuoteFromBoard = () => {
    if (!board) return;
    const lines = [
      `طلب تصنيع PCB من ملفات Gerber:`,
      `- اسم الملف: ${board.archiveName}`,
      `- المقاس المكتشف: ${board.widthMm} × ${board.heightMm} mm`,
      `- عدد الطبقات: ${board.layerCount} Layer`,
      `- لون الـ Solder Mask: ${maskTheme.label}`,
      `- نوع التشطيب: ${finish}`,
      `- عدد الثقوب (Drill): ${board.drillCount}`,
      `- الكمية المطلوبة: ... بوردة`,
    ];
    onUseForQuote(lines.join('\n'));
  };

  return (
    <div className="mt-10 bg-white border border-slate-200 rounded-xl overflow-hidden">
      {/* Header & Upload Trigger */}
      <div className="p-5 sm:p-7 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-1">
            معاينة ملفات Gerber قبل التصنيع (Top &amp; Bottom &amp; 3D)
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
            ارفع ملف الـ Gerber المضغوط (.zip) لمعاينة الوجه العلوي والسفلي أو عرض التصميم 3D، واختيار لون السولدر ماسك ونوع التشطيب.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <label className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer transition-colors whitespace-nowrap">
            <Upload className="w-4 h-4" />
            <span>{loading ? 'جاري التحليل...' : board ? 'رفع ملف Gerber آخر' : 'رفع ملف Gerber (.zip)'}</span>
            <input
              type="file"
              multiple
              accept=".zip,.gbr,.gtl,.gbl,.gts,.gbs,.gto,.gbo,.gko,.gm1,.gml,.drl,.xln,.txt"
              className="hidden"
              onChange={(e: ChangeEvent<HTMLInputElement>) => {
                handleFiles(e.target.files);
                e.target.value = '';
              }}
            />
          </label>
          {board && (
            <>
              <button
                type="button"
                onClick={() => setFullscreen3D(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg cursor-pointer transition-colors whitespace-nowrap"
              >
                <Box className="w-4 h-4 text-sky-700" />
                <span>فتح التصميم 3D</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setBoard(null);
                  setFullscreen3D(false);
                  setShowFilesList(false);
                  setError('');
                  setZoom(1);
                }}
                aria-label="مسح الملف الحالي"
                title="مسح الملف الحالي"
                className="inline-flex items-center gap-1 px-3 py-2.5 text-xs font-semibold text-slate-600 hover:text-red-600 bg-slate-50 hover:bg-red-50 border border-slate-200 rounded-lg cursor-pointer transition-colors whitespace-nowrap"
              >
                <X className="w-4 h-4" />
                <span>مسح</span>
              </button>
            </>
          )}
        </div>
      </div>

      {error && (
        <div role="alert" className="mx-5 sm:mx-7 mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs sm:text-sm text-red-700">
          {error}
        </div>
      )}

      {/* Empty State: Clean Drag & Drop Zone until user uploads Gerber */}
      {!board ? (
        <div className="p-5 sm:p-7">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl px-6 py-12 text-center transition-colors ${
              dragActive
                ? 'border-sky-500 bg-sky-50/70'
                : 'border-slate-300 bg-slate-50/60 hover:border-slate-400'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center mx-auto mb-3 shadow-xs">
              <FileArchive className="w-6 h-6 text-sky-700" />
            </div>
            <div className="text-sm sm:text-base font-bold text-slate-900 mb-1">
              اسحب ملف الـ Gerber (.zip) هنا أو اضغط للرفع
            </div>
            <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto mb-5 leading-relaxed">
              يدعم ملفات ZIP الكاملة أو ملفات الطبقات القياسية (GTL, GBL, GTS, GBS, GTO, GKO, DRL) لإظهار الوجه العلوي والسفلي مع إمكانية المعاينة 3D.
            </p>
            <label className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer transition-colors">
              <Upload className="w-4 h-4" />
              <span>{loading ? 'جاري قراءة الملف...' : 'اختيار ملف Gerber من جهازك'}</span>
              <input
                type="file"
                multiple
                accept=".zip,.gbr,.gtl,.gbl,.gts,.gbs,.gto,.gbo,.gko,.gm1,.gml,.drl,.xln,.txt"
                className="hidden"
                onChange={(e: ChangeEvent<HTMLInputElement>) => {
                  handleFiles(e.target.files);
                  e.target.value = '';
                }}
              />
            </label>
          </div>
        </div>
      ) : (
        <>
          {/* File Metadata Strip (Drag & Drop still works) */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className={`px-5 sm:px-7 py-3 border-b border-slate-200 transition-colors flex flex-wrap items-center justify-between gap-3 text-xs ${
              dragActive ? 'bg-sky-50 border-sky-300' : 'bg-slate-50/80'
            }`}
          >
            <div className="flex items-center gap-2 text-slate-600">
              <FileArchive className="w-4 h-4 text-sky-700 shrink-0" />
              <span>
                الملف الحالي:{' '}
                <strong className="font-mono-tech text-slate-900" dir="ltr">
                  {board.archiveName}
                </strong>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-slate-700 tabular-nums">
              <span>
                المقاس:{' '}
                <strong className="font-mono-tech text-slate-900">
                  {board.widthMm} × {board.heightMm} mm
                </strong>
              </span>
              <span aria-hidden="true" className="text-slate-300">
                ·
              </span>
              <span>
                الطبقات:{' '}
                <strong className="font-mono-tech text-slate-900">{board.layerCount} Layer</strong>
              </span>
              <span aria-hidden="true" className="text-slate-300">
                ·
              </span>
              <span>
                الثقوب: <strong className="font-mono-tech text-slate-900">{board.drillCount}</strong>
              </span>
              <button
                type="button"
                onClick={() => setShowFilesList((v) => !v)}
                className="text-sky-700 hover:text-sky-800 font-semibold cursor-pointer"
              >
                {showFilesList ? 'إخفاء الطبقات' : `الطبقات المكتشفة (${board.detectedFiles.length})`}
              </button>
            </div>
          </div>

          {showFilesList && (
            <div className="px-5 sm:px-7 py-3 bg-slate-50 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
              {board.detectedFiles.map((f, i) => (
                <div
                  key={`${f.filename}-${i}`}
                  className="bg-white border border-slate-200 rounded-lg px-3 py-2 flex flex-col"
                >
                  <span className="font-mono-tech text-slate-900 truncate" dir="ltr">
                    {f.filename}
                  </span>
                  <span className="text-slate-500 mt-0.5">{LAYER_LABELS[f.kind]}</span>
                </div>
              ))}
            </div>
          )}

      {/* Toolbar: View Mode + Colors + Finish + Layer Toggles + Zoom */}
      <div className="p-4 sm:px-7 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-white">
        {/* View Mode Segmented Switch */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
            {(
              [
                { id: 'both', label: 'Top + Bottom' },
                { id: 'top', label: 'Top فقط' },
                { id: 'bottom', label: 'Bottom فقط' },
                { id: '3d', label: 'عرض 3D' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setViewMode(opt.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  viewMode === opt.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Solder Mask Color Swatches */}
          <div className="flex items-center gap-1.5" role="group" aria-label="لون السولدر ماسك">
            <span className="text-xs text-slate-500 ml-1">اللون:</span>
            {MASK_THEMES.map((theme) => {
              const active = maskTheme.id === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  title={theme.label}
                  aria-label={theme.label}
                  onClick={() => setMaskTheme(theme)}
                  style={{ backgroundColor: theme.swatch }}
                  className={`w-6 h-6 rounded-full border flex items-center justify-center cursor-pointer transition-transform ${
                    active ? 'ring-2 ring-sky-600 ring-offset-1 scale-110 border-slate-900' : 'border-slate-300'
                  }`}
                >
                  {active && (
                    <Check
                      className={`w-3.5 h-3.5 ${
                        theme.id === 'white' ? 'text-slate-900' : 'text-white'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Surface Finish */}
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
            {(['HASL', 'ENIG'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFinish(f)}
                className={`px-2.5 py-1 text-xs font-mono-tech font-semibold rounded-md cursor-pointer ${
                  finish === f ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Layer Toggles & Zoom */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            {[
              { label: 'النحاس', active: showCopper, toggle: () => setShowCopper((v) => !v) },
              { label: 'البادات', active: showMask, toggle: () => setShowMask((v) => !v) },
              { label: 'الطباعة', active: showSilk, toggle: () => setShowSilk((v) => !v) },
              { label: 'الثقوب', active: showDrill, toggle: () => setShowDrill((v) => !v) },
            ].map((layer) => (
              <button
                key={layer.label}
                type="button"
                onClick={layer.toggle}
                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-semibold cursor-pointer transition-colors ${
                  layer.active
                    ? 'bg-sky-50 border-sky-200 text-sky-800'
                    : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{layer.label}</span>
              </button>
            ))}
          </div>

          {viewMode !== '3d' && (
            <div className="inline-flex items-center border border-slate-200 rounded-lg overflow-hidden bg-white">
              <button
                type="button"
                aria-label="تصغير"
                onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))}
                className="p-1.5 text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 text-xs font-mono-tech text-slate-700 tabular-nums">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                aria-label="تكبير"
                onClick={() => setZoom((z) => Math.min(4, Number((z + 0.25).toFixed(2))))}
                className="p-1.5 text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                aria-label="إعادة ضبط التكبير"
                onClick={() => setZoom(1)}
                className="p-1.5 text-slate-600 hover:bg-slate-100 border-r border-slate-200 cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Top & Bottom / 3D Preview Viewport */}
      <div className="p-4 sm:p-6 bg-slate-100/70">
        {viewMode === '3d' ? (
          <Gerber3DViewer
            board={board}
            theme={maskTheme}
            finish={finish}
            showCopper={showCopper}
            showMask={showMask}
            showSilk={showSilk}
            showDrill={showDrill}
            onToggleFullscreen={() => setFullscreen3D(true)}
          />
        ) : (
          <div
            className={`grid gap-4 ${
              viewMode === 'both' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'
            }`}
          >
            {(viewMode === 'both' || viewMode === 'top') && (
              <PcbSideCanvas
                side="top"
                board={board}
                theme={maskTheme}
                finish={finish}
                zoom={zoom}
                showCopper={showCopper}
                showMask={showMask}
                showSilk={showSilk}
                showDrill={showDrill}
              />
            )}
            {(viewMode === 'both' || viewMode === 'bottom') && (
              <PcbSideCanvas
                side="bottom"
                board={board}
                theme={maskTheme}
                finish={finish}
                zoom={zoom}
                showCopper={showCopper}
                showMask={showMask}
                showSilk={showSilk}
                showDrill={showDrill}
              />
            )}
          </div>
        )}

        <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-4 border-t border-slate-200">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Layers className="w-4 h-4 text-slate-500 shrink-0" />
            <span>
              {viewMode === '3d'
                ? 'اسحب للتدوير 360° أو مرر عجلة الماوس للتكبير وفحص البوردة من كل الزوايا.'
                : 'يمكنك تحريك اللوحة بالسحب أو التكبير لفحص المسارات والبادات قبل إرسال طلب التصنيع.'}
            </span>
          </div>
          <button
            type="button"
            onClick={handleQuoteFromBoard}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg cursor-pointer whitespace-nowrap shrink-0"
          >
            اعتماد المقاس وطلب تسعير لهذه البوردة
          </button>
        </div>
      </div>

          {/* Fullscreen 3D PCB Modal */}
          {fullscreen3D && (
            <div
              role="dialog"
              aria-modal="true"
              aria-label="معاينة التصميم 3D"
              onClick={() => setFullscreen3D(false)}
              className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-3 sm:p-6"
            >
              <div
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-6xl bg-slate-900 border border-slate-700 rounded-xl overflow-hidden shadow-2xl flex flex-col"
              >
                <div className="px-4 sm:px-6 py-3 border-b border-slate-800 flex items-center justify-between gap-4 text-white">
                  <div className="min-w-0">
                    <div className="text-sm sm:text-base font-bold truncate">
                      عارض البوردة ثلاثي الأبعاد (3D PCB Preview)
                    </div>
                    <div className="font-mono-tech text-xs text-slate-400 truncate" dir="ltr">
                      {board.archiveName} · {board.widthMm} × {board.heightMm} mm · {maskTheme.label} · {finish}
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label="إغلاق المعاينة ثلاثية الأبعاد"
                    onClick={() => setFullscreen3D(false)}
                    className="w-10 h-10 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center cursor-pointer shrink-0"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-3 sm:p-4 bg-slate-950">
                  <Gerber3DViewer
                    board={board}
                    theme={maskTheme}
                    finish={finish}
                    showCopper={showCopper}
                    showMask={showMask}
                    showSilk={showSilk}
                    showDrill={showDrill}
                    isFullscreen
                    onToggleFullscreen={() => setFullscreen3D(false)}
                  />
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
